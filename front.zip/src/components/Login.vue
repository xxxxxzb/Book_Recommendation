<!-- eslint-disable vue/multi-word-component-names -->
// eslint-disable-next-line vue/multi-word-component-names
<template>
  <div class="container" id="Application">
    <div class="container">
        <div class="subTitle">加入我们，一起创造美好世界</div>
        <h1 class="title">BookAdvertise</h1>
        <div v-for="(item, index) in fields" :key="index" class="inputContainer">
            <div class="field">{{item.title}} <span v-if="item.required" style="color: red;">*</span></div>
            <input v-model="item.model" class="input" :type="item.type" />
            <div class="tip" v-if="index == 2">请确认密码程度需要大于6位</div>
        </div>
        <button @click="loginAccount" class="btn">登录</button>
        <button @click="createAccount" class="btn">注册</button>
    </div>
</div>
  
</template>

<script>
export default {
    data() {
        return {
            fields:[
                {
                    title:"用户名",
                    required:true,
                    type:"text",
                    model:""
                },{
                    title:"密码",
                    required:true,
                    type:"password",
                    model:""
                }
            ],
            receiveMsg:false
        }
    },
    computed:{
        name: {
            get() {
                return this.fields[0].model
            },
            set(value){
                this.fields[0].model = value
            }
        },
        password: {
            get() {
                return this.fields[1].model
            },
            set(value){
                this.fields[1].model = value
            }
        }
    },
    methods:{
        loginAccount() {
            if (this.name.length == 0) {
                alert("请输入用户名")
                return
            } else if (this.password.length <= 6) {
                alert("密码需要大于6位字符")
                return
            }
            alert("登录成功")
            this.$router.push('/first')
            console.log(`name:${this.name}\npassword:${this.password}\nemail:${this.email}\nreceiveMsg:${this.receiveMsg}`)
        },
      createAccount(){
          this.$router.push('/register')
        }
    }
};
</script>

<style scoped>
.container {
    margin:0 auto;
    margin-top: 70px;
    text-align: center;
    width: 300px;
} 
.subTitle {
    color:gray;
    font-size: 14px;
}  
.title {
    font-size: 45px;  
}
.input {
    width: 90%;
}
.inputContainer {
    text-align: left;
    margin-bottom: 20px;
}
.subContainer {
    text-align: left;
}
.field {
    font-size: 14px;
}
.input {
    border-radius: 6px;
    height: 25px;
    margin-top: 10px;
    border-color: silver;
    border-style: solid;
    background-color: cornsilk;
}
.tip {
    margin-top: 5px;
    font-size: 12px;
    color: gray;
}
.setting {
    font-size: 9px;
    color: black;
}
.label {
    font-size: 12px;
    margin-left: 5px;
    height: 20px;
    vertical-align:middle;
}
.checkbox {
    height: 20px;
    vertical-align:middle;
}
.btn {
    border-radius: 10px;
    height: 40px;
    width: 140px;
    margin-top: 30px;
    margin-right: 10px;
    background-color: deepskyblue;
    border-color: blue;
    color: white;
}
</style>

<!--
  <div>
    <h1>注册</h1>
    <form @submit.prevent="submitForm">
      <div>
        <label>用户名</label>
        <input v-model="username" type="text" />
      </div>
      <div>
        <label>密码</label>
        <input v-model="password" type="password" />
      </div>
      <div>
        <button>注册</button>
      </div>
    </form>
  </div>
<script>
import axios from 'axios';
export default {
  data() {
    return {
      username: '',
      password: ''
    };
  },
  methods: {
    submitForm() {
      axios.post('http://localhost:8000/api/register/', { username: this.username, password: this.password })
        .then(response => {                           
          alert(response.data.msg);
          if (response.data.code === 200) {
            this.$router.push('/login');
          }
        })
        .catch(error => {
          console.log(error);
        });
    }
  }
};
</script>
-->