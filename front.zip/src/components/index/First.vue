<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <div>
    test
  </div>
</template>