import { createRouter, createWebHashHistory } from 'vue-router'
import Login from '@/components/Login.vue'
import Register from '@/components/Register.vue'
import First from '../components/index/First.vue'

const router = createRouter({
  history: createWebHashHistory(),
  routes:[
    {
      path:'/',
      redirect:'/login'
    },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path:'/register',
    name:'Register',
    component: Register
  },
  {
    path:'/first',
    name:'First',
    component: First
  }
  ]
})

export default router
